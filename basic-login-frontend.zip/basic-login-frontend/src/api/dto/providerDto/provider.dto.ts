
// interface representing data retrieved from the provider get request
export interface ProviderDTO {
    id: number;
    name: string;
}