// endpoint for login post request
const LOGIN_ENDPOINT = 'http://localhost:3000/login';
// endpoint for get of providers
const PROVIDERS_ENDPOINT = 'http://localhost:3000/providers';

export { LOGIN_ENDPOINT, PROVIDERS_ENDPOINT }